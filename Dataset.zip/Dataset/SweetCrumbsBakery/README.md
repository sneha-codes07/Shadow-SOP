# SweetCrumbsBakery Synthetic Dataset

This is a production-quality synthetic business dataset designed to represent the operations of **SweetCrumbsBakery** (a boutique bakery in Kolkata/Delhi, India) over a 3-month period from May 1, 2026, to July 20, 2026. 

The dataset contains exactly **120 orders** (including one pending order at the end of the timeline) and includes structured relational databases (CSVs) alongside unstructured communications (WhatsApp chat, emails, raw notes, and PDFs).

## Directory Structure
- `data/`
  - `orders.csv`: Main order logging database.
  - `invoices.csv`: Billing records, subtotal, GST (18%), and payment status.
  - `delivery_log.csv`: Delivery dispatches and completion times.
  - `payment_log.csv`: Transaction logs containing UPI, cash, card, and bank transfers.
  - `packaging_log.csv`: Logs detailing which packaging and stickers were used for each order.
  - `kitchen_schedule.csv`: Kitchen work tasks, bakers assigned, and actual preparation/baking times.
  - `inventory.csv`: Current ingredient and packaging stock levels.
  - `supplier_orders.csv`: Reorders placed with official wholesalers.
  - `employee_roster.csv`: Shift assignments for the bakery's four employees.
  - `customer_feedback.csv`: Customer reviews and ratings in mixed languages.
  - `whatsapp_chat.txt`: A full WhatsApp chat history of the team in English, Hindi, Hinglish, Bengali, and Bengali-English.
  - `emails.txt`: Email archive including corporate order quotes, customer complaints, and vendor notices.
  - `employee_notes.txt`: Informal scratchpad entries by the bakers.
  - `old_sop.txt` / `old_sop.pdf`: Standard Operating Procedures document.
  - `invoice.pdf`: Sample tax invoice for corporate order `ORD-1089`.

## Business Team Personas
1. **Priya Sharma (Owner/Manager)**: Manages sales, billing records, and client emails. Writes in English/Hinglish.
2. **Rahul Verma (Head Baker)**: Oversees daily baking and ingredient status. Writes in Hindi/Hinglish.
3. **Amit Das (Assistant Baker)**: Assists in baking and local retail errands. Writes in Bengali/Bengali-English.
4. **Vikram Singh (Delivery Coordinator)**: Packs boxes and runs delivery dispatches. Writes in Hindi/Hinglish.

## Key Process Anomalies to Discover (Process Mining & SOP Auditing)
An analyst or AI agent analyzing this dataset can discover several discrepancies between the official Standard Operating Procedure (`old_sop.txt`/`old_sop.pdf`) and actual employee behavior:
1. **SOP Bypass - Early Baking (Order `ORD-1042`)**: Officially, prep cannot start without 50% advance payment. However, for Mrs. Sen's urgent request on July 10, Priya told Rahul on WhatsApp to bake immediately. The kitchen schedule shows prep start at 10:30 AM, but the order and invoice were logged at 4:00 PM, and payment was received at 6:30 PM.
2. **Payment Reconciliation Lags (Orders `ORD-1025`, `ORD-1056`, `ORD-1099`)**: Customers paid immediately via GPay to Priya's personal account, but Priya only reconciled and logged them in `payment_log.csv` 4 days later.
3. **Logistics Bottleneck - Delivery Consolidation (Orders `ORD-1061`, `ORD-1062`, `ORD-1063`)**: On June 28, Vikram consolidated three South Kolkata deliveries. Despite items being packed by 2:00 PM, they were dispatched at 5:00 PM to save mileage. This led to melted cakes and poor reviews in `customer_feedback.csv`.
4. **Supply Chain Disruption & Local Purchase (June 15 & July 5)**: When cream cheese and butter ran dry due to logistics delays from Bengal Dairy, Amit bought retail blocks from "Kalyani Grocers" using cash. This was recorded in `employee_notes.txt`, bypassing the official `supplier_orders.csv` workflow.
5. **Packaging Supply Stockouts (June 20 - June 25)**: SweetCrumbs ran out of branded Eco-Boxes. The `packaging_log.csv` shows "Plain White Box" with no stickers applied. Corresponding reviews in `customer_feedback.csv` complain about the generic packaging.

This dataset is clean, relationally aligned, and ready for immediate loading into pandas, process mining tools (e.g., PM4Py), RAG engines, or LLM evaluation benches.
